package com.slu.andriod.weddingapp;

public class DeveloperKey {
    public static final String DEVELOPER_KEY = "AlzaSyBVpiqHiApHL26jBEWWTXhgtwTnKcHMp8Y";
}
