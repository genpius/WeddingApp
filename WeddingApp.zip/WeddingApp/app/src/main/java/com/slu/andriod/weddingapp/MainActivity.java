package com.slu.andriod.weddingapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.RelativeLayout;

public class MainActivity extends AppCompatActivity {

    RelativeLayout pictureLayout;
    RelativeLayout videoLayout;
    private TabLayout tabLayout;
    private ViewPager viewPager;
    private ViewPagerAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tabLayout = findViewById(R.id.tablayout_id);
        viewPager = findViewById(R.id.viewpager_id);
        adapter = new ViewPagerAdapter(getSupportFragmentManager());

        adapter.AddFragment(new FragmentPicture(), "");
        adapter.AddFragment(new FragmentVideo(), "");
        adapter.AddFragment(new FragmentMessage(), "");

        viewPager.setAdapter(adapter);
        tabLayout.setupWithViewPager(viewPager);

        tabLayout.getTabAt(0).setIcon(R.drawable.ic_picture);
        tabLayout.getTabAt(1).setIcon(R.drawable.ic_video);
        tabLayout.getTabAt(2).setIcon(R.drawable.ic_message);

    }

    public void moveToPic(View view) {
        Intent intent = new Intent(this, PicturesActivity.class);
        startActivity(intent);
    }

    public void moveToVidoes(View view) {
        Intent intent = new Intent(this, StandalonePlayerActivity.class);
        startActivity(intent);
    }

}
