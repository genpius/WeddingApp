package com.slu.andriod.weddingapp;

import android.content.Context;
import android.support.v4.view.PagerAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;

public class SlideAdapter extends PagerAdapter {

    private int[] lst_images = {
            R.drawable.couple_white,
            R.drawable.couple_stand,
            R.drawable.couple_walk,
            R.drawable.couple_em,
            R.drawable.couple_kiss
    };
    private Context context;
    private LayoutInflater inflater;

    SlideAdapter(Context context) {
        this.context = context;
    }

    @Override
    public int getCount() {
        return lst_images.length;
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return (view == object);
    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {
        inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(R.layout.slide_picture, container, false);
        LinearLayout layoutSlide = view.findViewById(R.id.slide_layout);
        ImageView pictures = view.findViewById(R.id.pic_holder);
        pictures.setImageResource(lst_images[position]);
        container.addView(view);
        return view;
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((LinearLayout) object);
    }
}
