package com.slu.andriod.weddingapp;

import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.text.TextUtils;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.google.android.youtube.player.YouTubeInitializationResult;
import com.google.android.youtube.player.YouTubeStandalonePlayer;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.slu.andriod.weddingapp.DeveloperKey.DEVELOPER_KEY;

/**
 * A simple YouTube Android API demo application which shows how to use a
 * {@link YouTubeStandalonePlayer} intent to start a YouTube video playback.
 */
public class StandalonePlayerActivity extends MainActivity implements View.OnClickListener {

    private static final int REQ_START_STANDALONE_PLAYER = 1;
    private static final int REQ_RESOLVE_SERVICE_MISSING = 2;

    private static final String VIDEO_ID = "nrZTXZMJpyM";
    private static final String PLAYLIST_ID = "7E952A67F31C58A3";
    private static final ArrayList<String> VIDEO_IDS = new ArrayList<>(Arrays.asList(
            "VU8OjTLEOVE", "hDXqkzrecto", "_XE9K2rXcyY", "50ByBFOfOrw",
            "9Qil5BbwHU4", "Nh0agMkVW5U", "O6pOVxBFCQ8", "pdZbDXXW7O8", "1D3_M5i5p5E"));

    private LinearLayout playBrideIntVideo;
    private LinearLayout playGroomIntVideo;
    private LinearLayout playParentIntVideo;
    private LinearLayout playChurchEntVideo;
    private LinearLayout playVowsVideo;
    private LinearLayout playReEntranceVideo;
    private LinearLayout playCuttingOfCakeVideo;
    private LinearLayout playCoupleDanceVideo;
    private LinearLayout playVoteOfThanksVideo;
    private FloatingActionButton fab;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_standalone_player);

        playBrideIntVideo = findViewById(R.id.bride_interview_video);
        playGroomIntVideo = findViewById(R.id.groom_interview_video);
        playParentIntVideo = findViewById(R.id.parent_interview_video);
        playChurchEntVideo = findViewById(R.id.church_entrance);
        playVowsVideo = findViewById(R.id.vow);
        playReEntranceVideo = findViewById(R.id.reception_entrance);
        playCuttingOfCakeVideo = findViewById(R.id.cutting_of_cake);
        playCoupleDanceVideo = findViewById(R.id.couple_dance);
        playVoteOfThanksVideo = findViewById(R.id.vote_of_thanks);

        fab = findViewById(R.id.fab_video_button);


        playBrideIntVideo.setOnClickListener(this);
        playGroomIntVideo.setOnClickListener(this);
        playParentIntVideo.setOnClickListener(this);
        playChurchEntVideo.setOnClickListener(this);
        playVowsVideo.setOnClickListener(this);
        playReEntranceVideo.setOnClickListener(this);
        playCuttingOfCakeVideo.setOnClickListener(this);
        playCoupleDanceVideo.setOnClickListener(this);
        playVoteOfThanksVideo.setOnClickListener(this);

        fab.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v == fab) {
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
            finish();
        }

        int startIndex = 0;
        int startTimeMillis = 0;

        Intent intent = null;
        if (v == playBrideIntVideo) {
            intent = YouTubeStandalonePlayer.createVideoIntent(
                    this, DEVELOPER_KEY, VIDEO_IDS.get(0), startTimeMillis, true, false);
        }
        if (v == playGroomIntVideo) {
            intent = YouTubeStandalonePlayer.createVideoIntent(
                    this, DEVELOPER_KEY, VIDEO_IDS.get(1), startTimeMillis, true, false);
        }
        if (v == playParentIntVideo) {
            intent = YouTubeStandalonePlayer.createVideoIntent(
                    this, DEVELOPER_KEY, VIDEO_IDS.get(2), startTimeMillis, true, false);
        }
        if (v == playChurchEntVideo) {
            intent = YouTubeStandalonePlayer.createVideoIntent(
                    this, DEVELOPER_KEY, VIDEO_IDS.get(3), startTimeMillis, true, false);
        }
        if (v == playVowsVideo) {
            intent = YouTubeStandalonePlayer.createVideoIntent(
                    this, DEVELOPER_KEY, VIDEO_IDS.get(4), startTimeMillis, true, false);
        }
        if (v == playReEntranceVideo) {
            intent = YouTubeStandalonePlayer.createVideoIntent(
                    this, DEVELOPER_KEY, VIDEO_IDS.get(5), startTimeMillis, true, false);
        }
        if (v == playCuttingOfCakeVideo) {
            intent = YouTubeStandalonePlayer.createVideoIntent(
                    this, DEVELOPER_KEY, VIDEO_IDS.get(6), startTimeMillis, true, false);
        }
        if (v == playCoupleDanceVideo) {
            intent = YouTubeStandalonePlayer.createVideoIntent(
                    this, DEVELOPER_KEY, VIDEO_IDS.get(7), startTimeMillis, true, false);
        }
        if (v == playVoteOfThanksVideo) {
            intent = YouTubeStandalonePlayer.createVideoIntent(
                    this, DEVELOPER_KEY, VIDEO_IDS.get(8), startTimeMillis, true, false);
        }

        if (intent != null) {
            if (canResolveIntent(intent)) {
                startActivityForResult(intent, REQ_START_STANDALONE_PLAYER);
            } else {
                // Could not resolve the intent - must need to install or update the YouTube API service.
                YouTubeInitializationResult.SERVICE_MISSING
                        .getErrorDialog(this, REQ_RESOLVE_SERVICE_MISSING).show();
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_START_STANDALONE_PLAYER && resultCode != RESULT_OK) {
            YouTubeInitializationResult errorReason =
                    YouTubeStandalonePlayer.getReturnedInitializationResult(data);
            if (errorReason.isUserRecoverableError()) {
                errorReason.getErrorDialog(this, 0).show();
            } else {
                String errorMessage =
                        String.format(getString(R.string.error_player), errorReason.toString());
                Toast.makeText(this, errorMessage, Toast.LENGTH_LONG).show();
            }
        }
    }

    private boolean canResolveIntent(Intent intent) {
        List<ResolveInfo> resolveInfo = getPackageManager().queryIntentActivities(intent, 0);
        return resolveInfo != null && !resolveInfo.isEmpty();
    }

    private int parseInt(String text, int defaultValue) {
        if (!TextUtils.isEmpty(text)) {
            try {
                return Integer.parseInt(text);
            } catch (NumberFormatException e) {
                // fall through
            }
        }
        return defaultValue;
    }


}

